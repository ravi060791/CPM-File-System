#include <stdio.h> 
#include <stdint.h> 
#include "cpmfsys.h" 
#include "diskSimulator.h"



int main(int argc, char * argv[]) { 
  uint8_t buffer1[BLOCK_SIZE],buffer2[BLOCK_SIZE]; 
  int i; 
  int filePointer; 
  int writeFilePointer,writePointer2; 
  readImage("image-ec-v2.img"); 
  makeFreeList();
  //initOpenFileList();
  cpmDir(); 
  printFreeList(); 
  cpmDelete("shortf.ps");
  cpmDir();
  cpmCopy("mytestf1.txt","mytestf2.txt");
  cpmCopy("mytestf1.txt","2ndcopy"); 
  cpmRename("mytestf1.txt","mytest2.tx");
  fprintf(stdout,"cpmRename return code = %d,\n",cpmRename("mytestf","mytestv2.x")); 
  cpmDir(); 
  printFreeList();
  filePointer = cpmOpen("mytestf2.txt",'r'); 
  fprintf(stdout,"cpmOpen(mytestf2.txt,r) = %d\n",filePointer); 
  fprintf(stdout,"cpmOpen(mytestf2.txt,r) = %d\n",cpmOpen("mytestf2.txt",'r')); 
  fprintf(stdout,"cpmOpen(blahblah,r) = %d\n",cpmOpen("blahblah",'r')); 
  fprintf(stdout,"cpmOpen(2ndcopy,w) = %d\n",writeFilePointer = cpmOpen("2ndcopy",'w')); 
  fprintf(stdout,"cpmOpen(blahblah,w) = %d\n",writePointer2 = cpmOpen("blahblah",'w')); 
  // copy some letters into the first bit of buffer1
  for (i=0;i< 10; i++) { 
    buffer1[i] = 0x66; 
  } 
  // overwrite the first few of them with the first 5 chars of mytest2f.txt
  cpmRead(filePointer,buffer1,5); 
  for (i=0;i<10;i++) { 
    fprintf(stdout,"%x ",buffer1[i]); 
  }
  fprintf(stdout,"\n"); 
  // set up a buffer for writing 
  for (i= 1; i < 8; i++) { 
    buffer1[i] = 0x66+i; 
  } 
  cpmWrite(writeFilePointer,buffer1,8);
  // now a big write
  // fill up most of a block of a new file 
  for (i=0; i< 1000; i++) { 
    buffer1[i] = 0x88; 
  }
  cpmWrite(writePointer2,buffer1,1000);
  // now write past the end of that block
  cpmWrite(writePointer2,buffer1,50);
  writeImage("ec-final-v2.img");
  cpmClose(filePointer); 
  cpmClose(writeFilePointer);
  printFreeList();
}
