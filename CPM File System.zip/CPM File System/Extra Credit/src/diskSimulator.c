#include <stdint.h> 
#include <stdio.h> 
#include "diskSimulator.h"
#include <ctype.h>
#include "cpmfsys.h"
// first index is sector number, second index is byte in the block of bytes
static uint8_t disk[256][1024];


int blockRead(uint8_t *buffer,uint8_t blockNum) { 
  int i = 0; 
  for (i=0; i<1024;i++) { 
    *(buffer+i) = disk[(int) blockNum][(int) i];
  } 
  return 0; 
} 

int  blockWrite(uint8_t *buffer,uint8_t blockNum) { 
  int  i = 0; 
  for (i=0; i<1024;i++) { 
    disk[(int) blockNum][i] = *(buffer+i);
  } 
  return 0; 
}

// for debugging purposes 
void printBlock(uint8_t blockNum) { 
  int i;
  fprintf(stdout,"\nDISK BLOCK %x:\n",blockNum); 
  for (i = 0; i < BLOCK_SIZE; i++) { 
    if (i % 16 == 0) { 
      fprintf(stdout,"%4x: ",i); 
    }
    	fprintf(stdout, "%2x ",disk[(int) blockNum][i]);
    if (i % 16 == 15) { 
      fprintf(stdout,"\n"); 
    }
  }
  fprintf(stdout,"\n"); 
} 

// read and write whole disk image, byte for byte from a Unix file
size_t writeImage(char *fileName) { 
  FILE *fp;
  size_t bytesWritten = -1; 
  fp = fopen(fileName,"w");
  bytesWritten = fwrite(disk,BLOCK_SIZE,NUM_BLOCKS,fp); 
  fclose(fp); 
  return bytesWritten; 
} 

size_t readImage(char *fileName) { 
  FILE *fp; 
  size_t bytesRead = -1; 
  fp = fopen(fileName,"r"); 
  // C uses row major order for multi dim arrays
  bytesRead = fread(disk,BLOCK_SIZE,NUM_BLOCKS,fp); 
  fclose(fp); 
  return bytesRead; 
  
} 

void printArray()
{
	for(int i=0;i<1;i++)
	{
		for(int j=0; j<1024;j++)
		{
			if (isalpha(disk[i][j]))
			{
				printf("%c ", disk[i][j]);
			}
			else if(isdigit(disk[i][j]))
			{
				printf("%d ", disk[i][j]);
			}
			else
			{
				printf("%u ", disk[i][j]);
			}
		}
		printf("\n");
	}
}

void mkdirStruct()
{
	DirStructType *dr = mkDirStruct(0,&disk[0][0]);
//		printf("%u ",dr->status);
//		for(int i =0;i<8;i++)
//			{
//				printf("%c ", dr->name[i]);
//			}
//		for(int j=0;j<3;j++)
//		{
//			printf("%c ", dr->extension[j]);
//		}
//		printf("%u ",dr->XL);
//		printf("%u ",dr->BC);
//		printf("%u ",dr->XH);
//		printf("%u ",dr->RC);
//		for(int k=0;k<16;k++)
//		{
//			printf("%u ",dr->blocks[k]);
//		}
		writeDirStruct(dr,31, &disk[0][0]);
}
